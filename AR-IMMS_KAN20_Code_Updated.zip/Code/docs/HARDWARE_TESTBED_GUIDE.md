# Hướng Dẫn Setup Testbed Phần Cứng Thực Tế — AR-IMMS (KAN-20)

> **Quan trọng:** Tài liệu này là **checklist thao tác** để bạn tự thực hiện và
> chụp ảnh màn hình/thiết bị thật. Không có công cụ nào có thể tạo "bằng chứng"
> phần cứng thay bạn — phần này bắt buộc phải làm thật, vì leader/giảng viên có
> thể yêu cầu demo trực tiếp.

## 1. Yêu cầu thiết bị

| Thiết bị | Vai trò | Ghi chú |
|---|---|---|
| 1 máy thật (laptop/PC) | Chạy **Backend** (Flask + Socket.IO) + **Frontend** (Vite dev server) | Có thể chạy 2 process trên cùng máy này |
| 1–2 máy ảo Ubuntu (VirtualBox/VMware/Hyper-V) | Chạy **Agent** gửi telemetry giả lập từ "node" khác | Mỗi VM đại diện 1 server node riêng |
| 1 điện thoại Android | Chạy **AR App** quét marker nhận diện server | Dùng Chrome/WebView của app AR-IMMS (hoặc app AR riêng nếu repo có) |
| Cùng 1 mạng LAN/WiFi | Máy thật, VM, điện thoại phải cùng subnet để gọi được IP máy thật | Kiểm tra bằng `ping` qua lại |

## 2. Chuẩn bị máy thật (Backend + Frontend)

1. Lấy địa chỉ IP LAN của máy thật:
   ```bash
   ip addr show | grep "inet "        # Linux
   ipconfig                            # Windows
   ```
   Giả sử IP là `192.168.1.50`.

2. Chạy Backend, lắng nghe trên tất cả interface (đã cấu hình sẵn `host='0.0.0.0'`
   trong `Code/backend/src/app.py`):
   ```bash
   cd Code/backend/src
   python app.py
   # -> Backend chạy tại 0.0.0.0:9999
   ```

3. Chạy Frontend, cũng cần bind ra ngoài LAN (không chỉ localhost):
   ```bash
   cd Code/frontend
   npm run dev -- --host 0.0.0.0
   # -> Frontend chạy tại 0.0.0.0:3000
   ```

4. **Chụp ảnh #1**: cửa sổ terminal cho thấy cả 2 service đang chạy (backend log
   "Running on http://0.0.0.0:9999" và frontend log "Local: http://localhost:3000/,
   Network: http://192.168.1.50:3000/").

## 3. Chuẩn bị máy ảo Ubuntu (Agent)

1. Tạo 1–2 VM Ubuntu (VirtualBox: chọn chế độ mạng **Bridged Adapter** để VM có
   IP riêng trong cùng LAN, không dùng NAT).

2. Trên mỗi VM, cài Python + clone repo (hoặc chỉ copy phần script agent/telemetry
   nếu có, ví dụ `Code/backend/src/scripts/test_streaming_engine.py` hoặc script
   agent gửi metric riêng nếu repo có):
   ```bash
   sudo apt update && sudo apt install -y python3 python3-pip git
   git clone <repo_url>
   cd <repo>/Code/backend
   pip3 install -r requirements.txt
   ```

3. Cấu hình agent trỏ về IP máy thật (thay vì `localhost`):
   ```bash
   export BACKEND_HOST=192.168.1.50
   export BACKEND_PORT=9999
   python3 src/scripts/test_streaming_engine.py   # hoặc script agent tương ứng
   ```
   > Nếu backend chưa có script "agent" gửi telemetry độc lập, đây là điểm cần bổ
   > sung thêm — có thể tái sử dụng logic trong `test_streaming_engine.py` làm nền,
   > chỉnh để gửi liên tục theo chu kỳ thay vì chạy 1 lần rồi thoát.

4. **Chụp ảnh #2**: terminal trên từng VM cho thấy agent đang kết nối và gửi dữ
   liệu thành công tới `192.168.1.50:9999` (log không có lỗi connection refused).

## 4. Xác nhận Dashboard nhận dữ liệu từ cả máy thật lẫn máy ảo

1. Trên máy thật (hoặc bất kỳ máy nào cùng LAN), mở trình duyệt vào
   `http://192.168.1.50:3000`, đăng nhập, vào tab **Digital Twin** (dashboard
   telemetry).

2. Quan sát danh sách node/rack — phải thấy dữ liệu đến từ node chạy trên máy
   thật **và** các node giả lập trên VM Ubuntu (phân biệt qua tên node/IP nguồn
   nếu dashboard hiển thị, hoặc qua thời điểm dữ liệu đổi khi tắt/bật từng VM).

3. Thử nghiệm xác nhận nguồn dữ liệu: tắt agent trên 1 VM, quan sát dashboard —
   số liệu của node tương ứng phải dừng cập nhật/chuyển trạng thái offline.
   Bật lại agent, dashboard phải nhận lại dữ liệu.

4. **Chụp ảnh #3**: Dashboard hiển thị đồng thời dữ liệu telemetry từ ≥ 2 nguồn
   (máy thật + ít nhất 1 VM), kèm timestamp/giờ hệ thống hiển thị trên màn hình
   để chứng minh đây là dữ liệu thời gian thực (không phải ảnh chụp cũ).

## 5. Điện thoại Android — AR App quét marker nhận diện server

1. Đảm bảo điện thoại cùng WiFi với máy thật.

2. Mở app AR-IMMS (hoặc trình duyệt di động trỏ tới `http://192.168.1.50:3000`
   nếu tính năng AR chạy qua web — kiểm tra `Code/frontend` có module AR/marker
   nào, ví dụ modal "Kích Hoạt Không Gian AR" trong `App.tsx`).

3. Cấp quyền Camera cho app/trình duyệt khi được hỏi.

4. In hoặc hiển thị marker/QR code của 1 server thật (lấy từ danh sách Assets
   trong dashboard — mỗi asset có GUID/QR riêng).

5. Dùng camera điện thoại quét marker, xác nhận app nhận diện đúng server (hiển
   thị tên, thông số, hoặc overlay AR tương ứng).

6. **Chụp ảnh #4**: màn hình điện thoại đang hiển thị kết quả quét — camera thấy
   marker thật + overlay/thông tin server hiện lên.

## 6. Tổng hợp bằng chứng nộp báo cáo

Tối thiểu cần có **4 ảnh chụp thật** theo checklist trên (#1–#4), đặt vào thư mục
`bang_chung_ket_qua_test/testbed-hardware/` với tên file rõ ràng, ví dụ:
```
01-terminal-backend-frontend-running.png
02-vm-ubuntu-agent-connected.png
03-dashboard-realtime-multi-source.png
04-android-ar-scan-marker.png
```

Nên quay thêm 1 đoạn video ngắn (30–60 giây) demo toàn bộ chuỗi: bật agent trên
VM → dashboard cập nhật → quét marker trên điện thoại, để làm bằng chứng thuyết
phục hơn ảnh tĩnh, đặc biệt nếu bị leader/giảng viên hỏi vặn trực tiếp.
