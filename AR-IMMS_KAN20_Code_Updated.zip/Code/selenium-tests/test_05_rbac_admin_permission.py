# -*- coding: utf-8 -*-
"""
Luồng 5: Kiểm tra phân quyền (RBAC)
  - Đăng nhập với tài khoản Admin -> nút "Mời Thành Viên" (admin-only) phải bấm được (enabled).
  - Đăng nhập với tài khoản Technician (user thường) -> nút "Mời Thành Viên" phải bị
    vô hiệu hoá (disabled), không thể bấm/kích hoạt hành động admin.
"""

from conftest import ADMIN_USER, TECH_USER, login, wait_for_login_success


def _open_users_tab(driver, wait, user):
    login(driver, wait, user["email"], user["password"])
    wait_for_login_success(driver, wait)
    driver.find_element("css selector", '[data-testid="nav-tab-users"]').click()
    return wait.until(lambda d: d.find_element("css selector", '[data-testid="admin-only-invite-user-button"]'))


def test_admin_can_click_admin_only_button(driver, wait, base_url):
    invite_btn = _open_users_tab(driver, wait, ADMIN_USER)
    assert invite_btn.get_attribute("disabled") is None, "Tài khoản Admin phải bấm được nút chỉ dành cho Admin"


def test_regular_user_cannot_click_admin_only_button(driver, wait, base_url):
    invite_btn = _open_users_tab(driver, wait, TECH_USER)
    assert invite_btn.get_attribute("disabled") is not None, (
        "Tài khoản Technician (user thường) KHÔNG được phép bấm nút chỉ dành cho Admin "
        "(nút phải ở trạng thái disabled)"
    )


def test_regular_user_admin_action_has_no_effect_even_if_forced(driver, wait, base_url):
    """
    Phòng trường hợp thuộc tính disabled bị can thiệp ở tầng DOM (vd. qua DevTools),
    handler phía React vẫn phải tự chặn hành động admin theo currentUser.role
    (defense-in-depth, không chỉ dựa vào UI disabled).
    """
    invite_btn = _open_users_tab(driver, wait, TECH_USER)

    # Ép click bằng JS bất chấp thuộc tính disabled trên DOM
    driver.execute_script("arguments[0].removeAttribute('disabled'); arguments[0].click();", invite_btn)

    # Modal đăng nhập/mời thành viên (AuthView) KHÔNG được mở ra cho user thường
    auth_views = driver.find_elements("css selector", '[data-testid="auth-view"]')
    assert len(auth_views) == 0, (
        "Hành động Admin-only vẫn không được thực thi dù nút bị ép bấm bằng JS, vì "
        "handler onInviteUser đã tự kiểm tra currentUser.role !== 'Admin'"
    )
