# -*- coding: utf-8 -*-
"""
Luồng 4: Tạo phiếu bảo trì Ticket mới
  - Từ 1 cảnh báo, bấm "Tạo Phiếu Xử Lý" -> mở form CreateTicketModal.
  - Điền/giữ nguyên thông tin mặc định, bấm submit.
  - Kiểm tra: modal đóng lại, phiếu mới xuất hiện trong "Danh Sách Phiếu Bảo Trì Đã Tạo".
"""

from conftest import ADMIN_USER, login, wait_for_login_success


def test_create_maintenance_ticket_and_appears_in_list(driver, wait, base_url):
    login(driver, wait, ADMIN_USER["email"], ADMIN_USER["password"])
    wait_for_login_success(driver, wait)

    driver.find_element("css selector", '[data-testid="nav-tab-alerts"]').click()

    alert_items = wait.until(lambda d: d.find_elements("css selector", '[data-testid^="alert-list-item-"]'))
    assert len(alert_items) > 0, "Cần có ít nhất 1 cảnh báo mẫu để test luồng tạo Ticket"
    alert_items[0].click()

    open_ticket_btn = wait.until(lambda d: d.find_element("css selector", '[data-testid="open-create-ticket-button"]'))
    open_ticket_btn.click()

    modal = wait.until(lambda d: d.find_element("css selector", '[data-testid="create-ticket-modal"]'))
    assert modal.is_displayed()

    tickets_before = len(driver.find_elements("css selector", '[data-testid^="ticket-list-item-"]'))

    submit_btn = driver.find_element("css selector", '[data-testid="create-ticket-submit-button"]')
    submit_btn.click()

    # Modal phải đóng lại sau khi submit
    wait.until(lambda d: len(d.find_elements("css selector", '[data-testid="create-ticket-modal"]')) == 0)

    # Phiếu mới phải xuất hiện trong danh sách
    ticket_list = wait.until(lambda d: d.find_element("css selector", '[data-testid="maintenance-ticket-list"]'))
    tickets_after = driver.find_elements("css selector", '[data-testid^="ticket-list-item-"]')
    assert len(tickets_after) == tickets_before + 1, (
        "Số lượng phiếu bảo trì trong danh sách phải tăng thêm 1 sau khi tạo ticket mới"
    )
    assert ticket_list.is_displayed()
