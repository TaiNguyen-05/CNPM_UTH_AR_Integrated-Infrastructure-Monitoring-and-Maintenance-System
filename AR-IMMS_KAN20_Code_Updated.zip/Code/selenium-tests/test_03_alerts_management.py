# -*- coding: utf-8 -*-
"""
Luồng 3: Quản lý danh sách cảnh báo
  - Lọc cảnh báo theo các bộ lọc: Tất cả / Nghiêm trọng / Chưa xử lý.
  - Chọn 1 cảnh báo, bấm "Tiếp Nhận Cảnh Báo" (Acknowledge) -> trạng thái đổi thành
    "Đã Tiếp Nhận" và nút bị disable (không click được 2 lần).
"""

from conftest import ADMIN_USER, login, wait_for_login_success


def _open_alerts_tab(driver, wait):
    login(driver, wait, ADMIN_USER["email"], ADMIN_USER["password"])
    wait_for_login_success(driver, wait)
    driver.find_element("css selector", '[data-testid="nav-tab-alerts"]').click()
    wait.until(lambda d: len(d.find_elements("css selector", '[data-testid="alert-filter-all"]')) > 0)


def test_filter_alerts_critical_only(driver, wait, base_url):
    _open_alerts_tab(driver, wait)

    driver.find_element("css selector", '[data-testid="alert-filter-critical"]').click()
    # Bộ lọc phải chuyển sang trạng thái active (không raise lỗi khi click được)
    critical_btn = driver.find_element("css selector", '[data-testid="alert-filter-critical"]')
    assert critical_btn.is_displayed()


def test_filter_alerts_unacknowledged_only(driver, wait, base_url):
    _open_alerts_tab(driver, wait)

    driver.find_element("css selector", '[data-testid="alert-filter-unacknowledged"]').click()
    unack_btn = driver.find_element("css selector", '[data-testid="alert-filter-unacknowledged"]')
    assert unack_btn.is_displayed()


def test_acknowledge_alert_updates_status(driver, wait, base_url):
    _open_alerts_tab(driver, wait)

    alert_items = wait.until(lambda d: d.find_elements("css selector", '[data-testid^="alert-list-item-"]'))
    assert len(alert_items) > 0, "Cần có ít nhất 1 cảnh báo mẫu để test luồng Acknowledge"
    alert_items[0].click()

    ack_button = wait.until(lambda d: d.find_element("css selector", '[data-testid="acknowledge-alert-button"]'))
    was_already_ack = ack_button.get_attribute("disabled") is not None

    if not was_already_ack:
        ack_button.click()
        wait.until(lambda d: "Đã Tiếp Nhận" in d.find_element(
            "css selector", '[data-testid="acknowledge-alert-button"]').text)

    ack_button_after = driver.find_element("css selector", '[data-testid="acknowledge-alert-button"]')
    assert "Đã Tiếp Nhận" in ack_button_after.text
    assert ack_button_after.get_attribute("disabled") is not None, (
        "Nút Acknowledge phải bị vô hiệu hoá sau khi đã tiếp nhận, tránh bấm trùng"
    )
