# Selenium E2E Test Suite — AR-IMMS (bổ sung KAN-20)

Bộ test tự động hoá giao diện Web bằng Selenium WebDriver + pytest, phủ 5 luồng
nghiệp vụ chính theo yêu cầu review:

| File | Luồng |
|---|---|
| `test_01_login_logout.py` | Đăng nhập / Đăng xuất (đúng & sai mật khẩu, lưu Token) |
| `test_02_telemetry_dashboard_realtime.py` | Dashboard Telemetry (cập nhật realtime qua WebSocket) |
| `test_03_alerts_management.py` | Lọc cảnh báo + bấm Acknowledge |
| `test_04_create_ticket.py` | Tạo phiếu bảo trì (mở form, submit, kiểm tra xuất hiện trên danh sách) |
| `test_05_rbac_admin_permission.py` | Kiểm tra phân quyền (user thường không bấm được nút Admin) |

## Yêu cầu môi trường

- Python 3.9+
- Google Chrome đã cài trên máy chạy test
- Backend đang chạy: `cd Code/backend/src && python app.py` (mặc định cổng **9999**)
- Frontend đang chạy: `cd Code/frontend && npm run dev` (mặc định cổng **3000**)

> Lưu ý: Selenium điều khiển **trình duyệt thật**, cần cả backend lẫn frontend
> đang chạy song song thì mới test được — không phải test kiểu mock.

## Cài đặt

```bash
cd Code/selenium-tests
pip install -r requirements.txt --break-system-packages
```

`selenium` 4.x tự động tải `chromedriver` khớp phiên bản Chrome đang cài (Selenium
Manager tích hợp sẵn từ Selenium 4.6+), không cần tải chromedriver thủ công.

## Chạy test

```bash
# Chạy toàn bộ (mặc định chạy headless)
pytest -v

# Chạy 1 luồng cụ thể
pytest -v test_03_alerts_management.py

# Xem trình duyệt thật khi chạy (debug)
SELENIUM_HEADLESS=0 pytest -v

# Trỏ tới URL khác (vd. môi trường staging)
BASE_URL=http://192.168.1.50:3000 pytest -v
```

## Tài khoản demo dùng trong test

| Vai trò | Email | Mật khẩu |
|---|---|---|
| Admin | sjenkins@ar-imms.corp | Demo@123 |
| Technician (user thường) | rking@ar-imms.corp | Demo@123 |

(Khớp với dữ liệu mẫu tại `Code/frontend/src/data/mockData.ts`)

## Ghi chú quan trọng

Bộ test này bám theo các thuộc tính `data-testid` đã được bổ sung vào code
frontend (xem các file đã sửa: `AuthView.tsx`, `App.tsx`, `AlertsView.tsx`,
`CreateTicketModal.tsx`, `UsersView.tsx`, `TelemetryView.tsx`). Nếu đổi tên/di
chuyển các `data-testid` này, cần cập nhật lại test tương ứng.
