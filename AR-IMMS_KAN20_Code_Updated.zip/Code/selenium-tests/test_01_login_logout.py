# -*- coding: utf-8 -*-
"""
Luồng 1: Đăng nhập / Đăng xuất
  - Đăng nhập với mật khẩu ĐÚNG -> vào được dashboard, token được lưu vào localStorage.
  - Đăng nhập với mật khẩu SAI -> hiển thị thông báo lỗi, KHÔNG vào được dashboard.
  - Đăng xuất -> token bị xoá khỏi localStorage, quay lại được màn hình đăng nhập.
"""

from conftest import ADMIN_USER, WRONG_PASSWORD, login, wait_for_login_success


def test_login_with_correct_password_succeeds_and_stores_token(driver, wait, base_url):
    login(driver, wait, ADMIN_USER["email"], ADMIN_USER["password"])
    wait_for_login_success(driver, wait)

    # Đăng nhập thành công -> thấy badge hồ sơ người dùng
    badge = driver.find_element("css selector", '[data-testid="user-profile-badge"]')
    assert badge.is_displayed()

    # Token phải được lưu vào localStorage sau khi đăng nhập
    token = driver.execute_script("return window.localStorage.getItem('ar_imms_auth_token');")
    assert token is not None and len(token) > 0, "Token đăng nhập phải được lưu vào localStorage"

    user_id = driver.execute_script("return window.localStorage.getItem('ar_imms_current_user_id');")
    assert user_id == "ADM-0001"


def test_login_with_wrong_password_shows_error_and_no_token(driver, wait, base_url):
    login(driver, wait, ADMIN_USER["email"], WRONG_PASSWORD)

    error_box = wait.until(lambda d: d.find_element("css selector", '[data-testid="login-error-message"]'))
    assert "mật khẩu" in error_box.text.lower() or "mat khau" in error_box.text.lower()

    # Không được vào dashboard, không có badge hồ sơ
    profile_badges = driver.find_elements("css selector", '[data-testid="user-profile-badge"]')
    assert len(profile_badges) == 0

    # Không được lưu token khi đăng nhập thất bại
    token = driver.execute_script("return window.localStorage.getItem('ar_imms_auth_token');")
    assert token is None


def test_logout_clears_token_and_returns_to_login(driver, wait, base_url):
    login(driver, wait, ADMIN_USER["email"], ADMIN_USER["password"])
    wait_for_login_success(driver, wait)

    logout_btn = driver.find_element("css selector", '[data-testid="logout-button"]')
    logout_btn.click()

    # Sau khi đăng xuất, badge hồ sơ phải biến mất
    wait.until(lambda d: len(d.find_elements("css selector", '[data-testid="user-profile-badge"]')) == 0)

    token = driver.execute_script("return window.localStorage.getItem('ar_imms_auth_token');")
    assert token is None, "Token phải bị xoá khỏi localStorage sau khi đăng xuất"
