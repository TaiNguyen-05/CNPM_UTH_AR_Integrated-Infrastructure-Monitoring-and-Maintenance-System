# -*- coding: utf-8 -*-
"""
Luồng 2: Xem Dashboard Telemetry & Rack 3D Digital Twin (cập nhật realtime)
  - Đăng nhập, mở tab "Digital Twin" (dashboard telemetry chính).
  - Kiểm tra dashboard render đầy đủ (không lỗi trắng trang).
  - Kiểm tra dữ liệu cập nhật theo thời gian thực: chụp snapshot nội dung 2 lần,
    cách nhau vài giây, khi bật "Luồng Trực Tiếp" (WebSocket streaming) nội dung
    (giá trị đo đạc CPU/RAM/Temp) phải khác nhau giữa 2 lần chụp.
"""

import time

from conftest import ADMIN_USER, login, wait_for_login_success


def test_telemetry_dashboard_renders_after_login(driver, wait, base_url):
    login(driver, wait, ADMIN_USER["email"], ADMIN_USER["password"])
    wait_for_login_success(driver, wait)

    nav_twin = driver.find_element("css selector", '[data-testid="nav-tab-twin"]')
    nav_twin.click()

    dashboard = wait.until(lambda d: d.find_element("css selector", '[data-testid="telemetry-dashboard"]'))
    assert dashboard.is_displayed()
    assert "Luồng Đo Từ Xa" in dashboard.text or "Telemetry" in dashboard.text


def test_telemetry_values_update_in_realtime(driver, wait, base_url):
    login(driver, wait, ADMIN_USER["email"], ADMIN_USER["password"])
    wait_for_login_success(driver, wait)

    driver.find_element("css selector", '[data-testid="nav-tab-twin"]').click()
    dashboard = wait.until(lambda d: d.find_element("css selector", '[data-testid="telemetry-dashboard"]'))

    # Đảm bảo streaming đang bật (mặc định bật sẵn theo code hiện tại)
    assert "Luồng Trực Tiếp" in dashboard.text or "Live" in dashboard.text.lower(), (
        "Chế độ streaming realtime phải đang bật mặc định để kiểm tra được cập nhật dữ liệu"
    )

    snapshot_1 = dashboard.text
    time.sleep(4)  # đợi vài chu kỳ cập nhật dữ liệu qua WebSocket
    snapshot_2 = dashboard.text

    assert snapshot_1 != snapshot_2, (
        "Nội dung Dashboard Telemetry phải thay đổi theo thời gian (dữ liệu realtime "
        "qua WebSocket), nhưng 2 lần chụp giống hệt nhau."
    )
