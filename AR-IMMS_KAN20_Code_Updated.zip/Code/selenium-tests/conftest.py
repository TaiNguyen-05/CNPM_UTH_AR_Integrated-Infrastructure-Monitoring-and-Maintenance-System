# -*- coding: utf-8 -*-
"""
conftest.py — Cấu hình chung cho bộ Selenium E2E Test (KAN-20 bổ sung).

Yêu cầu trước khi chạy:
  1. Backend đang chạy tại BASE_API_URL (mặc định http://localhost:9999)
  2. Frontend (Vite dev server) đang chạy tại BASE_URL (mặc định http://localhost:3000)
     Lệnh: cd Code/frontend && npm run dev
  3. Đã cài Google Chrome + chromedriver tương thích (hoặc dùng webdriver-manager,
     xem requirements.txt).

Cài đặt:
  pip install -r requirements.txt --break-system-packages

Chạy toàn bộ:
  pytest -v

Chạy 1 luồng cụ thể:
  pytest -v test_03_alerts_management.py

Biến môi trường có thể override:
  BASE_URL          (mặc định http://localhost:3000)
  SELENIUM_HEADLESS (mặc định "1" = chạy headless; đặt "0" để xem trình duyệt thật)
"""

import os
import time

import pytest
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait


BASE_URL = os.environ.get("BASE_URL", "http://localhost:3000")
HEADLESS = os.environ.get("SELENIUM_HEADLESS", "1") != "0"
DEFAULT_TIMEOUT = 10


# ---------------------------------------------------------------------------
# Tài khoản demo (khớp với Code/frontend/src/data/mockData.ts)
# ---------------------------------------------------------------------------
ADMIN_USER = {"email": "sjenkins@ar-imms.corp", "password": "Demo@123", "role": "Admin", "name": "Sarah Jenkins"}
TECH_USER = {"email": "rking@ar-imms.corp", "password": "Demo@123", "role": "Technician", "name": "Robert King"}
WRONG_PASSWORD = "SaiMatKhau@123"


@pytest.fixture(scope="function")
def driver():
    options = Options()
    if HEADLESS:
        options.add_argument("--headless=new")
    options.add_argument("--window-size=1440,900")
    options.add_argument("--no-sandbox")
    options.add_argument("--disable-dev-shm-usage")
    options.add_argument("--disable-gpu")
    # Cho phép giả lập quyền camera (dùng cho luồng QR/AR nếu cần) mà không cần popup thật
    options.add_experimental_option("prefs", {
        "profile.default_content_setting_values.media_stream_camera": 1,
    })

    drv = webdriver.Chrome(options=options)
    drv.implicitly_wait(2)
    yield drv
    drv.quit()


@pytest.fixture(scope="function")
def wait(driver):
    return WebDriverWait(driver, DEFAULT_TIMEOUT)


@pytest.fixture(scope="function")
def base_url():
    return BASE_URL


def login(driver, wait, email: str, password: str):
    """Helper dùng chung: mở app, bấm nút đăng nhập, điền form, submit."""
    driver.get(BASE_URL)
    open_btn = wait.until(lambda d: d.find_element("css selector", '[data-testid="open-login-button"]'))
    open_btn.click()

    email_input = wait.until(lambda d: d.find_element("css selector", '[data-testid="login-email-input"]'))
    email_input.clear()
    email_input.send_keys(email)

    password_input = driver.find_element("css selector", '[data-testid="login-password-input"]')
    password_input.clear()
    password_input.send_keys(password)

    driver.find_element("css selector", '[data-testid="login-submit-button"]').click()


def wait_for_login_success(driver, wait):
    wait.until(lambda d: d.find_element("css selector", '[data-testid="user-profile-badge"]'))
    # AuthView có 450ms delay giả lập network -> chờ thêm chút để localStorage kịp ghi
    time.sleep(0.3)
