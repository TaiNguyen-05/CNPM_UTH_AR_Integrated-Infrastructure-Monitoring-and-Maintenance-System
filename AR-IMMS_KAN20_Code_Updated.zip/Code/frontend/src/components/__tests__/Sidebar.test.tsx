import { describe, it, expect, vi } from 'vitest';
import { render, screen, fireEvent } from '@testing-library/react';
import '@testing-library/jest-dom/vitest';

import { Sidebar } from '../Sidebar';
import { UserItem } from '../../types';

const mockUser: UserItem = {
  id: 'usr-1',
  userId: 'ADM-0001',
  name: 'Sarah Jenkins',
  email: 'sjenkins@ar-imms.corp',
  role: 'Admin',
  status: 'Active',
  lastAuth: 'Current Session',
  initials: 'SJ',
};

function renderSidebar(overrides: Partial<React.ComponentProps<typeof Sidebar>> = {}) {
  const defaultProps: React.ComponentProps<typeof Sidebar> = {
    currentTab: 'digital-twin',
    onSelectTab: vi.fn(),
    openMobileMenu: false,
    onCloseMobileMenu: vi.fn(),
    alertCount: 0,
    pendingUsersCount: 0,
    currentUser: mockUser,
    onOpenSupport: vi.fn(),
    onSignOut: vi.fn(),
    ...overrides,
  };
  render(<Sidebar {...defaultProps} />);
  return defaultProps;
}

describe('Sidebar component', () => {
  it('hiển thị đầy đủ 6 mục điều hướng chính', () => {
    renderSidebar();
    expect(screen.getByText('Mặt Bằng Digital Twin')).toBeInTheDocument();
    expect(screen.getByText('Chỉ Số Đo Từ Xa')).toBeInTheDocument();
    expect(screen.getByText('Tài Sản & Mã QR AR')).toBeInTheDocument();
    expect(screen.getByText('Cảnh Báo & Sự Cố')).toBeInTheDocument();
    expect(screen.getByText('Người Dùng & Phân Quyền')).toBeInTheDocument();
    expect(screen.getByText('Nhật Ký Kiểm Toán')).toBeInTheDocument();
  });

  it('gọi onSelectTab và onCloseMobileMenu khi bấm một mục điều hướng', () => {
    const onSelectTab = vi.fn();
    const onCloseMobileMenu = vi.fn();
    renderSidebar({ onSelectTab, onCloseMobileMenu });
    fireEvent.click(screen.getByText('Cảnh Báo & Sự Cố'));
    expect(onSelectTab).toHaveBeenCalledWith('alerts');
    expect(onCloseMobileMenu).toHaveBeenCalledTimes(1);
  });

  it('hiển thị badge số lượng cảnh báo (alertCount) trên mục Cảnh Báo & Sự Cố', () => {
    renderSidebar({ alertCount: 5 });
    expect(screen.getByText('5')).toBeInTheDocument();
  });

  it('không hiển thị badge khi alertCount = 0', () => {
    renderSidebar({ alertCount: 0, pendingUsersCount: 0 });
    expect(screen.queryByText(/^[1-9]\d*$/)).not.toBeInTheDocument();
  });

  it('hiển thị badge số lượng user đang chờ duyệt (pendingUsersCount) trên mục Người Dùng', () => {
    renderSidebar({ pendingUsersCount: 3 });
    expect(screen.getByText('3')).toBeInTheDocument();
  });

  it('gọi onSignOut khi bấm nút Đăng Xuất', () => {
    const onSignOut = vi.fn();
    renderSidebar({ onSignOut });
    fireEvent.click(screen.getByText('Đăng Xuất'));
    expect(onSignOut).toHaveBeenCalledTimes(1);
  });

  it('gọi onOpenSupport khi bấm nút Tài Liệu & Trợ Giúp', () => {
    const onOpenSupport = vi.fn();
    renderSidebar({ onOpenSupport });
    fireEvent.click(screen.getByText('Tài Liệu & Trợ Giúp'));
    expect(onOpenSupport).toHaveBeenCalledTimes(1);
  });

  it('hiển thị mục đang active theo currentTab', () => {
    renderSidebar({ currentTab: 'alerts' });
    const activeButton = screen.getByText('Cảnh Báo & Sự Cố').closest('button');
    expect(activeButton?.className).toMatch(/text-sky-400/);
  });
});
