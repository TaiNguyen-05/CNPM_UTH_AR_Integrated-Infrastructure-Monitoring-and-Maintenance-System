import { describe, it, expect, vi } from 'vitest';
import { render, screen, fireEvent } from '@testing-library/react';
import '@testing-library/jest-dom/vitest';

import { Header } from '../Header';
import { AlertItem, UserItem } from '../../types';

const mockUser: UserItem = {
  id: 'usr-1',
  userId: 'ADM-0001',
  name: 'Sarah Jenkins',
  email: 'sjenkins@ar-imms.corp',
  role: 'Admin',
  status: 'Active',
  lastAuth: 'Current Session',
  initials: 'SJ',
};

function renderHeader(overrides: Partial<React.ComponentProps<typeof Header>> = {}) {
  const defaultProps: React.ComponentProps<typeof Header> = {
    currentTab: 'digital-twin',
    onSelectTab: vi.fn(),
    alerts: [],
    currentUser: mockUser,
    onSignOut: vi.fn(),
    onOpenNewAsset: vi.fn(),
    onOpenSettings: vi.fn(),
    onOpenSupport: vi.fn(),
    onMobileMenuToggle: vi.fn(),
    searchQuery: '',
    onSearchChange: vi.fn(),
    ...overrides,
  };
  render(<Header {...defaultProps} />);
  return defaultProps;
}

describe('Header component', () => {
  it('hiển thị tên người dùng hiện tại đang đăng nhập', () => {
    renderHeader();
    expect(screen.getByText('Sarah Jenkins')).toBeInTheDocument();
  });

  it('hiển thị tên demo mặc định khi không có currentUser', () => {
    renderHeader({ currentUser: null });
    expect(screen.getByText('Sarah Jenkins')).toBeInTheDocument();
  });

  it('gọi onSelectTab đúng id khi bấm vào một liên kết điều hướng trên thanh nav', () => {
    const onSelectTab = vi.fn();
    renderHeader({ onSelectTab });
    fireEvent.click(screen.getByText('Hardware // AR'));
    expect(onSelectTab).toHaveBeenCalledWith('assets-qr');
  });

  it('gọi onOpenNewAsset khi bấm nút thêm thiết bị mới', () => {
    const onOpenNewAsset = vi.fn();
    renderHeader({ onOpenNewAsset });
    fireEvent.click(screen.getByTitle('Thêm thiết bị mới'));
    expect(onOpenNewAsset).toHaveBeenCalledTimes(1);
  });

  it('mở menu hồ sơ và gọi onSignOut khi bấm "Terminate Session"', () => {
    const onSignOut = vi.fn();
    renderHeader({ onSignOut });

    expect(screen.queryByText('Terminate Session')).not.toBeInTheDocument();
    fireEvent.click(screen.getByText('SJ'));
    const signOutBtn = screen.getByText('Terminate Session');
    fireEvent.click(signOutBtn);
    expect(onSignOut).toHaveBeenCalledTimes(1);
  });

  it('gọi onOpenSettings khi bấm "System Config" trong menu hồ sơ', () => {
    const onOpenSettings = vi.fn();
    renderHeader({ onOpenSettings });
    fireEvent.click(screen.getByText('SJ'));
    fireEvent.click(screen.getByText('System Config'));
    expect(onOpenSettings).toHaveBeenCalledTimes(1);
  });

  it('hiển thị badge số lượng cảnh báo chưa xử lý trên tab Incidents', () => {
    const alerts: AlertItem[] = [
      { id: 'a1', acknowledged: false, resolved: false } as AlertItem,
      { id: 'a2', acknowledged: true, resolved: false } as AlertItem,
      { id: 'a3', acknowledged: false, resolved: true } as AlertItem,
    ];
    renderHeader({ alerts });
    expect(screen.getByText('1')).toBeInTheDocument();
  });

  it('không hiển thị badge khi không có cảnh báo nào đang mở', () => {
    renderHeader({ alerts: [] });
    expect(screen.queryByText(/^[1-9]\d*$/)).not.toBeInTheDocument();
  });
});
