import { describe, it, expect, vi } from 'vitest';
import { render, screen, fireEvent } from '@testing-library/react';
import '@testing-library/jest-dom/vitest';

import { CreateTicketModal } from '../CreateTicketModal';
import { AlertItem } from '../../../types';

const mockAlert: AlertItem = {
  id: 'alert-001',
  alertCode: 'ALM-1023',
  title: 'Nhiệt độ Rack A3 vượt ngưỡng',
  location: 'Zone A / Rack A3',
  severity: 'Critical',
  time: '2 phút trước',
  acknowledged: false,
  resolved: false,
} as AlertItem;

function renderModal(overrides: Partial<React.ComponentProps<typeof CreateTicketModal>> = {}) {
  const defaultProps: React.ComponentProps<typeof CreateTicketModal> = {
    alert: mockAlert,
    onClose: vi.fn(),
    onAssignTicket: vi.fn(),
    ...overrides,
  };
  render(<CreateTicketModal {...defaultProps} />);
  return defaultProps;
}

describe('CreateTicketModal component', () => {
  it('mở form và hiển thị đúng thông tin cảnh báo nguồn (alertCode, title)', () => {
    renderModal();
    expect(screen.getByTestId('create-ticket-modal')).toBeInTheDocument();
    expect(screen.getByText(/ALM-1023/)).toBeInTheDocument();
    expect(screen.getAllByText(/Nhiệt độ Rack A3 vượt ngưỡng/).length).toBeGreaterThan(0);
  });

  it('submit form gọi onAssignTicket với đúng alertId, assignee mặc định và ghi chú, rồi đóng modal', () => {
    const onAssignTicket = vi.fn();
    const onClose = vi.fn();
    renderModal({ onAssignTicket, onClose });

    fireEvent.submit(screen.getByTestId('create-ticket-form'));

    expect(onAssignTicket).toHaveBeenCalledTimes(1);
    const [alertId, assignee, notes] = onAssignTicket.mock.calls[0];
    expect(alertId).toBe('alert-001');
    expect(assignee).toBe('Sarah Jenkins');
    expect(notes).toContain('Nhiệt độ Rack A3 vượt ngưỡng');
    expect(onClose).toHaveBeenCalledTimes(1);
  });

  it('cho phép đổi kỹ thuật viên phụ trách trước khi submit', () => {
    const onAssignTicket = vi.fn();
    renderModal({ onAssignTicket });

    fireEvent.change(screen.getByTestId('create-ticket-assignee-select'), {
      target: { value: 'Robert King' },
    });
    fireEvent.submit(screen.getByTestId('create-ticket-form'));

    const [, assignee] = onAssignTicket.mock.calls[0];
    expect(assignee).toBe('Robert King');
  });

  it('gọi onClose khi bấm nút Hủy Bỏ mà không gọi onAssignTicket', () => {
    const onClose = vi.fn();
    const onAssignTicket = vi.fn();
    renderModal({ onClose, onAssignTicket });

    fireEvent.click(screen.getByText('Hủy Bỏ'));
    expect(onClose).toHaveBeenCalledTimes(1);
    expect(onAssignTicket).not.toHaveBeenCalled();
  });

  it('gọi onClose khi bấm nút "x" ở góc modal', () => {
    const onClose = vi.fn();
    renderModal({ onClose });
    const closeButtons = screen.getAllByRole('button');
    fireEvent.click(closeButtons[0]);
    expect(onClose).toHaveBeenCalledTimes(1);
  });
});
