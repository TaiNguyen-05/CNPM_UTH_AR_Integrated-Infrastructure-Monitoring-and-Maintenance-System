import { describe, it, expect, vi } from 'vitest';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom/vitest';

import { QRScannerModal } from '../QRScannerModal';
import { AssetItem } from '../../../types';

const mockAssets: AssetItem[] = [
  {
    id: 'srv-001', name: 'Node Alpha-01', model: 'DL380', rack: 'Rack A3',
    uPosition: 'U12', qrStatus: 'Active', guid: 'GUID-AAA-111',
    manufacturer: 'HPE', serialNumber: 'SN-0001', installDate: '2024-01-01',
    powerDraw: '450W', networkInterfaces: ['eth0'],
  },
  {
    id: 'srv-002', name: 'Node Beta-02', model: 'R740', rack: 'Rack B1',
    uPosition: 'U04', qrStatus: 'Active', guid: 'GUID-BBB-222',
    manufacturer: 'Dell', serialNumber: 'SN-0002', installDate: '2024-02-01',
    powerDraw: '400W', networkInterfaces: ['eth0'],
  },
];

function renderModal(overrides: Partial<React.ComponentProps<typeof QRScannerModal>> = {}) {
  const defaultProps: React.ComponentProps<typeof QRScannerModal> = {
    assets: mockAssets,
    onClose: vi.fn(),
    onSelectAsset: vi.fn(),
    ...overrides,
  };
  render(<QRScannerModal {...defaultProps} />);
  return defaultProps;
}

describe('QRScannerModal component', () => {
  it('render modal quét QR và hiển thị danh sách chọn nhanh thiết bị mẫu', () => {
    renderModal();
    expect(screen.getByTestId('qr-scanner-modal')).toBeInTheDocument();
    expect(screen.getByText('Node Alpha-01')).toBeInTheDocument();
    expect(screen.getByText('Node Beta-02')).toBeInTheDocument();
  });

  it('chọn nhanh một thiết bị mẫu sẽ gọi onSelectAsset và onClose', () => {
    const onSelectAsset = vi.fn();
    const onClose = vi.fn();
    renderModal({ onSelectAsset, onClose });

    fireEvent.click(screen.getByTestId('qr-quick-select-srv-001'));

    expect(onSelectAsset).toHaveBeenCalledWith(mockAssets[0]);
    expect(onClose).toHaveBeenCalledTimes(1);
  });

  it('tra cứu thủ công theo đúng GUID sẽ tìm thấy thiết bị và đóng modal', () => {
    const onSelectAsset = vi.fn();
    const onClose = vi.fn();
    renderModal({ onSelectAsset, onClose });

    fireEvent.change(screen.getByTestId('qr-manual-code-input'), {
      target: { value: 'GUID-BBB-222' },
    });
    fireEvent.click(screen.getByTestId('qr-manual-lookup-button'));

    expect(onSelectAsset).toHaveBeenCalledWith(mockAssets[1]);
    expect(onClose).toHaveBeenCalledTimes(1);
  });

  it('tra cứu thủ công theo mã không tồn tại sẽ hiển thị lỗi và không đóng modal', async () => {
    const onSelectAsset = vi.fn();
    const onClose = vi.fn();
    renderModal({ onSelectAsset, onClose });

    fireEvent.change(screen.getByTestId('qr-manual-code-input'), {
      target: { value: 'khong-ton-tai-123' },
    });
    fireEvent.click(screen.getByTestId('qr-manual-lookup-button'));

    await waitFor(() => {
      expect(screen.getByTestId('qr-error-message')).toBeInTheDocument();
    });
    expect(onSelectAsset).not.toHaveBeenCalled();
    expect(onClose).not.toHaveBeenCalled();
  });

  it('gọi onClose khi bấm nút đóng modal', () => {
    const onClose = vi.fn();
    renderModal({ onClose });
    const closeButtons = screen.getAllByRole('button');
    fireEvent.click(closeButtons[0]);
    expect(onClose).toHaveBeenCalledTimes(1);
  });

  it('không hiển thị video khi môi trường không có camera (jsdom không hỗ trợ mediaDevices)', () => {
    renderModal();
    expect(screen.getByText(/Đang kết nối Camera|Chưa cấp quyền Camera/)).toBeInTheDocument();
  });
});
