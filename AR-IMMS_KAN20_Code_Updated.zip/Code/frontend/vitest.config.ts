import react from '@vitejs/plugin-react';
import path from 'path';
import { defineConfig } from 'vitest/config';

// Cấu hình Vitest riêng cho Unit Test React Component (KAN-20 bổ sung).
// Chạy: npm run test  (hoặc: npx vitest run)
export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: {
      '@': path.resolve(__dirname, '.'),
    },
  },
  test: {
    environment: 'jsdom',
    globals: true,
    setupFiles: ['./src/test/setupTests.ts'],
    css: false,
    include: ['src/**/*.test.{ts,tsx}'],
  },
});
