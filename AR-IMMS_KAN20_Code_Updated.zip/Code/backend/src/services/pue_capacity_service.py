# -*- coding: utf-8 -*-
"""
PUE Analytics & Capacity Planning Service
==========================================
Module bổ sung theo yêu cầu review KAN-20:
  1. Tính PUE (Power Usage Effectiveness) = Total Facility Power / IT Equipment Power,
     xử lý an toàn khi chia cho 0, và cảnh báo khi PUE vượt ngưỡng cấu hình (mặc định 2.0).
  2. Dự báo Capacity Planning: dựa trên xu hướng tăng trưởng tuyến tính (linear regression)
     của một chỉ số (RAM % hoặc Disk %) theo thời gian, tính số ngày còn lại trước khi
     chỉ số đó chạm ngưỡng cấu hình (mặc định 90%).
  3. Tổng hợp báo cáo xu hướng (trend report) theo khoảng thời gian tuỳ chọn (7 ngày / 30 ngày).

Toàn bộ hàm trong module này là "pure function" (không truy vấn DB trực tiếp) để có thể
unit test độc lập, nhanh, không cần khởi tạo Flask app / DB thật. Controller ở
`api/controllers/analytics_controller.py` chịu trách nhiệm lấy dữ liệu từ DB rồi gọi
các hàm ở đây.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import List, Optional, Sequence, Dict, Any


# --------------------------------------------------------------------------
# 1. PUE (Power Usage Effectiveness)
# --------------------------------------------------------------------------

DEFAULT_PUE_ALERT_THRESHOLD = 2.0


class InvalidPowerReadingError(ValueError):
    """Ném ra khi thông số công suất đầu vào không hợp lệ (âm)."""


@dataclass
class PueResult:
    total_power_kw: float
    it_power_kw: float
    pue: Optional[float]
    rating: str                 # "EXCELLENT" | "GOOD" | "AVERAGE" | "POOR" | "INVALID"
    alert_triggered: bool
    error: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "total_power_kw": self.total_power_kw,
            "it_power_kw": self.it_power_kw,
            "pue": self.pue,
            "rating": self.rating,
            "alert_triggered": self.alert_triggered,
            "error": self.error,
        }


def _rate_pue(pue: float) -> str:
    """Phân loại hiệu suất năng lượng theo thang đo phổ biến của ngành Data Center."""
    if pue < 1.2:
        return "EXCELLENT"
    if pue < 1.5:
        return "GOOD"
    if pue <= 2.0:
        return "AVERAGE"
    return "POOR"


def calculate_pue(
    total_power_kw: float,
    it_power_kw: float,
    alert_threshold: float = DEFAULT_PUE_ALERT_THRESHOLD,
) -> PueResult:
    """
    Tính PUE = Total Facility Power / IT Equipment Power.

    - Nếu it_power_kw == 0  -> không thể chia cho 0, trả kết quả lỗi có kiểm soát
      (KHÔNG raise exception ra ngoài, để API luôn trả JSON hợp lệ cho Dashboard).
    - Nếu total_power_kw < 0 hoặc it_power_kw < 0 -> raise InvalidPowerReadingError.
    - Nếu total_power_kw < it_power_kw -> dữ liệu công suất phi vật lý (IT power không
      thể lớn hơn tổng công suất), trả kết quả lỗi có kiểm soát thay vì PUE < 1 sai lệch.
    - alert_triggered = True khi pue > alert_threshold (mặc định 2.0).
    """
    if total_power_kw < 0 or it_power_kw < 0:
        raise InvalidPowerReadingError(
            "Công suất không thể âm: total_power_kw={}, it_power_kw={}".format(
                total_power_kw, it_power_kw
            )
        )

    if it_power_kw == 0:
        return PueResult(
            total_power_kw=total_power_kw,
            it_power_kw=it_power_kw,
            pue=None,
            rating="INVALID",
            alert_triggered=False,
            error="Không thể tính PUE: IT Power = 0 (chia cho 0).",
        )

    if total_power_kw < it_power_kw:
        return PueResult(
            total_power_kw=total_power_kw,
            it_power_kw=it_power_kw,
            pue=None,
            rating="INVALID",
            alert_triggered=False,
            error="Dữ liệu không hợp lệ: Total Power nhỏ hơn IT Power.",
        )

    pue = round(total_power_kw / it_power_kw, 4)
    rating = _rate_pue(pue)
    alert_triggered = pue > alert_threshold

    return PueResult(
        total_power_kw=total_power_kw,
        it_power_kw=it_power_kw,
        pue=pue,
        rating=rating,
        alert_triggered=alert_triggered,
    )


# --------------------------------------------------------------------------
# 2. Capacity Planning (dự báo cạn kiệt tài nguyên RAM / Disk)
# --------------------------------------------------------------------------

@dataclass
class CapacityPoint:
    """Một điểm dữ liệu lịch sử: mốc thời gian (giờ, tính từ điểm đầu tiên) và giá trị (%)."""
    hours_from_start: float
    value_percent: float


@dataclass
class CapacityForecastResult:
    metric: str
    current_value_percent: float
    growth_rate_percent_per_day: float
    threshold_percent: float
    days_remaining: Optional[float]   # None nếu không có xu hướng tăng (an toàn / không dự báo được)
    projected_full_date: Optional[str]
    status: str   # "ALREADY_OVER_THRESHOLD" | "FORECASTED" | "STABLE_OR_DECREASING" | "INSUFFICIENT_DATA"

    def to_dict(self) -> Dict[str, Any]:
        return {
            "metric": self.metric,
            "current_value_percent": self.current_value_percent,
            "growth_rate_percent_per_day": self.growth_rate_percent_per_day,
            "threshold_percent": self.threshold_percent,
            "days_remaining": self.days_remaining,
            "projected_full_date": self.projected_full_date,
            "status": self.status,
        }


def _linear_regression_slope_intercept(points: Sequence[CapacityPoint]):
    """
    Hồi quy tuyến tính đơn giản (least squares) trên (x=giờ, y=%).
    Trả về (slope, intercept) theo đơn vị %/giờ.
    """
    n = len(points)
    sum_x = sum(p.hours_from_start for p in points)
    sum_y = sum(p.value_percent for p in points)
    sum_xy = sum(p.hours_from_start * p.value_percent for p in points)
    sum_xx = sum(p.hours_from_start ** 2 for p in points)

    denominator = (n * sum_xx) - (sum_x ** 2)
    if denominator == 0:
        # Tất cả các điểm có cùng mốc thời gian -> không tính được độ dốc
        return 0.0, sum_y / n

    slope = ((n * sum_xy) - (sum_x * sum_y)) / denominator
    intercept = (sum_y - slope * sum_x) / n
    return slope, intercept


def forecast_capacity(
    metric: str,
    history: Sequence[CapacityPoint],
    threshold_percent: float = 90.0,
    now: Optional[datetime] = None,
) -> CapacityForecastResult:
    """
    Dự báo số ngày còn lại trước khi chỉ số (RAM/Disk %) chạm ngưỡng `threshold_percent`,
    dựa trên xu hướng tăng trưởng tuyến tính của lịch sử `history` (yêu cầu >= 2 điểm,
    được sắp xếp tăng dần theo thời gian).

    - Nếu history có ít hơn 2 điểm -> INSUFFICIENT_DATA, days_remaining = None.
    - Nếu current_value đã >= threshold -> ALREADY_OVER_THRESHOLD, days_remaining = 0.
    - Nếu tốc độ tăng trưởng <= 0 (đi ngang hoặc giảm) -> STABLE_OR_DECREASING,
      days_remaining = None (không có nguy cơ cạn kiệt theo xu hướng hiện tại).
    - Ngược lại -> FORECASTED, tính days_remaining = (threshold - current) / (%/ngày).
    """
    now = now or datetime.utcnow()

    if len(history) < 2:
        return CapacityForecastResult(
            metric=metric,
            current_value_percent=history[-1].value_percent if history else 0.0,
            growth_rate_percent_per_day=0.0,
            threshold_percent=threshold_percent,
            days_remaining=None,
            projected_full_date=None,
            status="INSUFFICIENT_DATA",
        )

    ordered = sorted(history, key=lambda p: p.hours_from_start)
    current_value = ordered[-1].value_percent

    slope_per_hour, _intercept = _linear_regression_slope_intercept(ordered)
    growth_rate_per_day = round(slope_per_hour * 24, 6)

    if current_value >= threshold_percent:
        return CapacityForecastResult(
            metric=metric,
            current_value_percent=current_value,
            growth_rate_percent_per_day=growth_rate_per_day,
            threshold_percent=threshold_percent,
            days_remaining=0.0,
            projected_full_date=now.isoformat(),
            status="ALREADY_OVER_THRESHOLD",
        )

    if growth_rate_per_day <= 0:
        return CapacityForecastResult(
            metric=metric,
            current_value_percent=current_value,
            growth_rate_percent_per_day=growth_rate_per_day,
            threshold_percent=threshold_percent,
            days_remaining=None,
            projected_full_date=None,
            status="STABLE_OR_DECREASING",
        )

    days_remaining = round((threshold_percent - current_value) / growth_rate_per_day, 2)
    projected_full_date = None
    try:
        from datetime import timedelta
        projected_full_date = (now + timedelta(days=days_remaining)).isoformat()
    except OverflowError:
        projected_full_date = None

    return CapacityForecastResult(
        metric=metric,
        current_value_percent=current_value,
        growth_rate_percent_per_day=growth_rate_per_day,
        threshold_percent=threshold_percent,
        days_remaining=days_remaining,
        projected_full_date=projected_full_date,
        status="FORECASTED",
    )


# --------------------------------------------------------------------------
# 3. Trend Report (xuất báo cáo xu hướng 7 ngày / 30 ngày)
# --------------------------------------------------------------------------

@dataclass
class TrendReport:
    metric: str
    period_days: int
    sample_count: int
    min_percent: float
    max_percent: float
    avg_percent: float
    start_percent: float
    end_percent: float
    change_percent: float          # end - start
    growth_rate_percent_per_day: float

    def to_dict(self) -> Dict[str, Any]:
        return {
            "metric": self.metric,
            "period_days": self.period_days,
            "sample_count": self.sample_count,
            "min_percent": self.min_percent,
            "max_percent": self.max_percent,
            "avg_percent": self.avg_percent,
            "start_percent": self.start_percent,
            "end_percent": self.end_percent,
            "change_percent": self.change_percent,
            "growth_rate_percent_per_day": self.growth_rate_percent_per_day,
        }


SUPPORTED_TREND_PERIODS_DAYS = (7, 30)


class UnsupportedTrendPeriodError(ValueError):
    pass


def build_trend_report(
    metric: str,
    history: Sequence[CapacityPoint],
    period_days: int,
) -> TrendReport:
    """
    Tổng hợp báo cáo xu hướng cho `period_days` ngày gần nhất (chỉ hỗ trợ 7 hoặc 30 ngày
    theo đúng yêu cầu). `history` là toàn bộ điểm dữ liệu đã có, hàm sẽ tự lọc ra các điểm
    nằm trong `period_days` ngày gần nhất kể từ điểm cuối cùng.
    """
    if period_days not in SUPPORTED_TREND_PERIODS_DAYS:
        raise UnsupportedTrendPeriodError(
            f"period_days={period_days} không được hỗ trợ, chỉ nhận {SUPPORTED_TREND_PERIODS_DAYS}"
        )

    if not history:
        return TrendReport(
            metric=metric, period_days=period_days, sample_count=0,
            min_percent=0.0, max_percent=0.0, avg_percent=0.0,
            start_percent=0.0, end_percent=0.0, change_percent=0.0,
            growth_rate_percent_per_day=0.0,
        )

    ordered = sorted(history, key=lambda p: p.hours_from_start)
    last_hour = ordered[-1].hours_from_start
    cutoff_hour = last_hour - (period_days * 24)
    window = [p for p in ordered if p.hours_from_start >= cutoff_hour]

    values = [p.value_percent for p in window]
    slope_per_hour, _ = _linear_regression_slope_intercept(window) if len(window) >= 2 else (0.0, 0.0)

    return TrendReport(
        metric=metric,
        period_days=period_days,
        sample_count=len(window),
        min_percent=round(min(values), 2),
        max_percent=round(max(values), 2),
        avg_percent=round(sum(values) / len(values), 2),
        start_percent=round(window[0].value_percent, 2),
        end_percent=round(window[-1].value_percent, 2),
        change_percent=round(window[-1].value_percent - window[0].value_percent, 2),
        growth_rate_percent_per_day=round(slope_per_hour * 24, 4),
    )
