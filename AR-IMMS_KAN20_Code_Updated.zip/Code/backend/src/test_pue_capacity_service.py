# -*- coding: utf-8 -*-
"""
Unit Test cho Module PUE Analytics & Capacity Planning (bổ sung theo review KAN-20).

Chạy trực tiếp (không cần Flask app / DB thật vì service là pure function):
    python test_pue_capacity_service.py

Hoặc chạy bằng pytest (nếu đã cài `pip install pytest --break-system-packages`):
    pytest test_pue_capacity_service.py -v
"""

from services.pue_capacity_service import (
    calculate_pue,
    forecast_capacity,
    build_trend_report,
    CapacityPoint,
    InvalidPowerReadingError,
    UnsupportedTrendPeriodError,
)


# ==========================================================
# 1. TEST CÔNG THỨC PUE
# ==========================================================

def test_pue_formula_basic():
    """PUE = Total Power / IT Power, ví dụ 42kW / 28kW = 1.5 (AVERAGE, đúng ngưỡng)."""
    result = calculate_pue(total_power_kw=42.0, it_power_kw=28.0)
    assert result.pue == 1.5
    assert result.rating == "AVERAGE"
    assert result.alert_triggered is False
    assert result.error is None


def test_pue_excellent_rating():
    result = calculate_pue(total_power_kw=11.0, it_power_kw=10.0)  # PUE = 1.1
    assert result.pue == 1.1
    assert result.rating == "EXCELLENT"


def test_pue_divide_by_zero_is_handled_safely():
    """IT Power = 0 -> không được raise exception, phải trả kết quả lỗi có kiểm soát."""
    result = calculate_pue(total_power_kw=50.0, it_power_kw=0.0)
    assert result.pue is None
    assert result.rating == "INVALID"
    assert result.alert_triggered is False
    assert result.error is not None


def test_pue_negative_power_raises_error():
    try:
        calculate_pue(total_power_kw=-5.0, it_power_kw=10.0)
        assert False, "Phải raise InvalidPowerReadingError khi công suất âm"
    except InvalidPowerReadingError:
        pass


def test_pue_total_less_than_it_power_is_invalid():
    """Total Power không thể nhỏ hơn IT Power về mặt vật lý."""
    result = calculate_pue(total_power_kw=10.0, it_power_kw=20.0)
    assert result.pue is None
    assert result.rating == "INVALID"


def test_pue_alert_triggered_above_threshold():
    """PUE > 2.0 (mặc định) phải kích hoạt cảnh báo (POOR)."""
    result = calculate_pue(total_power_kw=45.0, it_power_kw=20.0)  # PUE = 2.25
    assert result.pue == 2.25
    assert result.rating == "POOR"
    assert result.alert_triggered is True


def test_pue_alert_not_triggered_at_exactly_threshold():
    """PUE = đúng 2.0 (ngưỡng) thì KHÔNG kích hoạt cảnh báo (chỉ > 2.0 mới alert)."""
    result = calculate_pue(total_power_kw=40.0, it_power_kw=20.0)  # PUE = 2.0
    assert result.pue == 2.0
    assert result.alert_triggered is False
    assert result.rating == "AVERAGE"


def test_pue_custom_alert_threshold():
    result = calculate_pue(total_power_kw=30.0, it_power_kw=20.0, alert_threshold=1.4)  # PUE = 1.5
    assert result.alert_triggered is True


# ==========================================================
# 2. TEST DỰ BÁO CAPACITY PLANNING
# ==========================================================

def test_capacity_forecast_insufficient_data():
    result = forecast_capacity("ram", history=[CapacityPoint(0, 50.0)])
    assert result.status == "INSUFFICIENT_DATA"
    assert result.days_remaining is None

    result_empty = forecast_capacity("ram", history=[])
    assert result_empty.status == "INSUFFICIENT_DATA"


def test_capacity_forecast_growth_trend_predicts_days_remaining():
    """
    RAM tăng đều 2%/ngày (48%/giờ trong ví dụ theo giờ): 0h=60%, 24h=62%, 48h=64%.
    Ngưỡng 90% -> còn (90-64)/2 = 13 ngày kể từ điểm cuối.
    """
    history = [
        CapacityPoint(hours_from_start=0, value_percent=60.0),
        CapacityPoint(hours_from_start=24, value_percent=62.0),
        CapacityPoint(hours_from_start=48, value_percent=64.0),
    ]
    result = forecast_capacity("ram", history, threshold_percent=90.0)
    assert result.status == "FORECASTED"
    assert abs(result.growth_rate_percent_per_day - 2.0) < 0.01
    assert abs(result.days_remaining - 13.0) < 0.1
    assert result.projected_full_date is not None


def test_capacity_forecast_already_over_threshold():
    history = [
        CapacityPoint(hours_from_start=0, value_percent=88.0),
        CapacityPoint(hours_from_start=24, value_percent=93.0),
    ]
    result = forecast_capacity("disk", history, threshold_percent=90.0)
    assert result.status == "ALREADY_OVER_THRESHOLD"
    assert result.days_remaining == 0.0


def test_capacity_forecast_stable_or_decreasing_trend():
    """Xu hướng đi ngang / giảm -> không có nguy cơ cạn kiệt, days_remaining = None."""
    history = [
        CapacityPoint(hours_from_start=0, value_percent=70.0),
        CapacityPoint(hours_from_start=24, value_percent=68.0),
        CapacityPoint(hours_from_start=48, value_percent=69.0),
    ]
    result = forecast_capacity("ram", history, threshold_percent=90.0)
    assert result.status == "STABLE_OR_DECREASING"
    assert result.days_remaining is None


# ==========================================================
# 3. TEST API XUẤT BÁO CÁO XU HƯỚNG (7 NGÀY / 30 NGÀY)
# ==========================================================

def _build_linear_history(days: int, start_value: float, growth_per_day: float, step_hours: float = 6.0):
    points = []
    total_hours = days * 24
    h = 0.0
    while h <= total_hours:
        points.append(CapacityPoint(hours_from_start=h, value_percent=start_value + growth_per_day * (h / 24.0)))
        h += step_hours
    return points


def test_trend_report_7_days():
    history = _build_linear_history(days=10, start_value=50.0, growth_per_day=1.0)
    report = build_trend_report("ram", history, period_days=7)
    assert report.period_days == 7
    assert report.sample_count > 0
    assert report.change_percent > 0
    assert abs(report.growth_rate_percent_per_day - 1.0) < 0.05


def test_trend_report_30_days():
    history = _build_linear_history(days=35, start_value=40.0, growth_per_day=0.5)
    report = build_trend_report("disk", history, period_days=30)
    assert report.period_days == 30
    assert report.sample_count > 0
    assert abs(report.growth_rate_percent_per_day - 0.5) < 0.05


def test_trend_report_rejects_unsupported_period():
    try:
        build_trend_report("ram", history=[CapacityPoint(0, 50.0)], period_days=14)
        assert False, "Phải raise UnsupportedTrendPeriodError cho period_days không hỗ trợ"
    except UnsupportedTrendPeriodError:
        pass


def test_trend_report_empty_history():
    report = build_trend_report("ram", history=[], period_days=7)
    assert report.sample_count == 0
    assert report.change_percent == 0.0


# ==========================================================
# Chạy trực tiếp bằng `python test_pue_capacity_service.py`
# ==========================================================

if __name__ == "__main__":
    import sys
    import traceback

    test_functions = [
        (name, obj) for name, obj in list(globals().items())
        if name.startswith("test_") and callable(obj)
    ]

    print("=" * 70)
    print("  UNIT TEST: PUE ANALYTICS & CAPACITY PLANNING (KAN-20 bổ sung)")
    print("=" * 70)

    passed, failed = 0, 0
    for name, fn in test_functions:
        try:
            fn()
            print(f"✅ PASS: {name}")
            passed += 1
        except Exception:
            print(f"❌ FAIL: {name}")
            traceback.print_exc()
            failed += 1

    print("-" * 70)
    print(f"Kết quả: {passed}/{passed + failed} test PASS")
    print("=" * 70)
    sys.exit(0 if failed == 0 else 1)
