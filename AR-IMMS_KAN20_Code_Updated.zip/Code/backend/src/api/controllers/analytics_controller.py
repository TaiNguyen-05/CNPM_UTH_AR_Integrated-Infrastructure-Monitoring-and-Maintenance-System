# -*- coding: utf-8 -*-
"""
Analytics Controller — PUE (Power Usage Effectiveness) & Capacity Planning API.

Bổ sung theo yêu cầu review KAN-20 (2. Module PUE Analytics & Capacity Planning).
Toàn bộ logic tính toán nằm trong `services/pue_capacity_service.py` (pure function,
được unit test riêng trong `test_pue_capacity_service.py`) — controller này chỉ đóng
vai trò lấy dữ liệu từ DB / request rồi gọi service.
"""

from datetime import datetime
from flask import Blueprint, request, jsonify

from infrastructure.databases.db_session import db_session
from infrastructure.models.ar_models import ServerNodeModel, RackModel, MetricLogModel
from services.pue_capacity_service import (
    calculate_pue,
    forecast_capacity,
    build_trend_report,
    CapacityPoint,
    InvalidPowerReadingError,
    UnsupportedTrendPeriodError,
    DEFAULT_PUE_ALERT_THRESHOLD,
)

analytics_bp = Blueprint("analytics", __name__, url_prefix="/api/analytics")


# --------------------------------------------------------------------------
# 1. PUE
# --------------------------------------------------------------------------

@analytics_bp.route("/pue", methods=["POST"])
def compute_pue():
    """
    Body JSON:
    {
      "total_power_kw": 42.0,
      "it_power_kw": 28.0,
      "alert_threshold": 2.0   // optional, mặc định 2.0
    }
    """
    data = request.get_json(silent=True) or {}
    try:
        total_power_kw = float(data.get("total_power_kw", 0))
        it_power_kw = float(data.get("it_power_kw", 0))
    except (TypeError, ValueError):
        return jsonify({"error": "total_power_kw và it_power_kw phải là số"}), 400

    alert_threshold = float(data.get("alert_threshold", DEFAULT_PUE_ALERT_THRESHOLD))

    try:
        result = calculate_pue(total_power_kw, it_power_kw, alert_threshold=alert_threshold)
    except InvalidPowerReadingError as e:
        return jsonify({"error": str(e)}), 400

    status_code = 200 if result.error is None else 422
    return jsonify(result.to_dict()), status_code


@analytics_bp.route("/pue/rack/<rack_id>", methods=["GET"])
def compute_rack_pue(rack_id):
    """
    Ước tính PUE cho một rack dựa trên power_limit_kw (Total Facility Power, do vận hành
    cấu hình) và tổng công suất ước tính của các node đang hoạt động trong rack (IT Power),
    lấy xấp xỉ theo tỉ lệ CPU% ở lần đo gần nhất * công suất định mức 0.3kW/node (giả định
    tham chiếu). Query string cho phép override thủ công `total_power_kw` / `it_power_kw`.
    """
    session = db_session()
    try:
        rack = session.query(RackModel).filter(RackModel.id == rack_id).first()
        if not rack:
            return jsonify({"error": f"Rack {rack_id} không tồn tại"}), 404

        override_total = request.args.get("total_power_kw", type=float)
        override_it = request.args.get("it_power_kw", type=float)

        if override_total is not None and override_it is not None:
            total_power_kw = override_total
            it_power_kw = override_it
        else:
            nodes = session.query(ServerNodeModel).filter(ServerNodeModel.rack_id == rack_id).all()
            it_power_kw = 0.0
            for node in nodes:
                latest = (
                    session.query(MetricLogModel)
                    .filter(MetricLogModel.server_node_id == node.id)
                    .order_by(MetricLogModel.timestamp.desc())
                    .first()
                )
                cpu_pct = latest.cpu if latest and latest.cpu is not None else 0.0
                # Công suất ước tính node = 0.15kW idle + 0.15kW * (cpu% / 100) tải thêm
                it_power_kw += 0.15 + 0.15 * (cpu_pct / 100.0)
            total_power_kw = rack.power_limit_kw if rack.power_limit_kw else it_power_kw

        result = calculate_pue(total_power_kw, it_power_kw)
        payload = result.to_dict()
        payload["rack_id"] = rack_id
        status_code = 200 if result.error is None else 422
        return jsonify(payload), status_code
    except InvalidPowerReadingError as e:
        return jsonify({"error": str(e)}), 400
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    finally:
        session.close()


# --------------------------------------------------------------------------
# 2. Capacity Planning
# --------------------------------------------------------------------------

def _load_history_points(session, node_id: str, metric: str, days: int = 30):
    if metric not in ("ram", "disk"):
        raise ValueError("metric phải là 'ram' hoặc 'disk'")

    logs = (
        session.query(MetricLogModel)
        .filter(MetricLogModel.server_node_id == node_id)
        .order_by(MetricLogModel.timestamp.asc())
        .all()
    )
    if not logs:
        return []

    t0 = logs[0].timestamp
    points = []
    for log in logs:
        value = getattr(log, metric)
        if value is None:
            continue
        hours = (log.timestamp - t0).total_seconds() / 3600.0
        points.append(CapacityPoint(hours_from_start=hours, value_percent=value))
    return points


@analytics_bp.route("/capacity-planning/<node_id>", methods=["GET"])
def capacity_planning(node_id):
    """
    Query params:
      - metric: 'ram' | 'disk' (mặc định 'ram')
      - threshold: ngưỡng % cạn kiệt (mặc định 90.0)
    """
    metric = request.args.get("metric", default="ram")
    threshold = request.args.get("threshold", default=90.0, type=float)

    session = db_session()
    try:
        node = session.query(ServerNodeModel).filter(ServerNodeModel.id == node_id).first()
        if not node:
            return jsonify({"error": f"Node {node_id} không tồn tại"}), 404

        try:
            history = _load_history_points(session, node_id, metric)
        except ValueError as e:
            return jsonify({"error": str(e)}), 400

        result = forecast_capacity(metric, history, threshold_percent=threshold)
        payload = result.to_dict()
        payload["node_id"] = node_id
        return jsonify(payload), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    finally:
        session.close()


# --------------------------------------------------------------------------
# 3. Trend Report (7 ngày / 30 ngày)
# --------------------------------------------------------------------------

@analytics_bp.route("/trend-report/<node_id>", methods=["GET"])
def trend_report(node_id):
    """
    Query params:
      - metric: 'ram' | 'disk' | 'cpu' | 'temp' (mặc định 'ram')
      - period: 7 | 30 (ngày, mặc định 7)
    """
    metric = request.args.get("metric", default="ram")
    period_days = request.args.get("period", default=7, type=int)

    session = db_session()
    try:
        node = session.query(ServerNodeModel).filter(ServerNodeModel.id == node_id).first()
        if not node:
            return jsonify({"error": f"Node {node_id} không tồn tại"}), 404

        if metric not in ("ram", "disk", "cpu", "temp"):
            return jsonify({"error": "metric phải là 'ram', 'disk', 'cpu' hoặc 'temp'"}), 400

        logs = (
            session.query(MetricLogModel)
            .filter(MetricLogModel.server_node_id == node_id)
            .order_by(MetricLogModel.timestamp.asc())
            .all()
        )
        if not logs:
            history = []
        else:
            t0 = logs[0].timestamp
            history = [
                CapacityPoint(
                    hours_from_start=(log.timestamp - t0).total_seconds() / 3600.0,
                    value_percent=getattr(log, metric),
                )
                for log in logs
                if getattr(log, metric) is not None
            ]

        try:
            result = build_trend_report(metric, history, period_days)
        except UnsupportedTrendPeriodError as e:
            return jsonify({"error": str(e)}), 400

        payload = result.to_dict()
        payload["node_id"] = node_id
        return jsonify(payload), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    finally:
        session.close()
